/** @type {import('next').NextConfig} */
const nextConfig = {
  // remova: experimental: { serverActions: true },
}

export default nextConfig
